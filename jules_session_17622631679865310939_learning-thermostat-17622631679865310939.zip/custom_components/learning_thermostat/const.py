"""Constants for the Learning Thermostat integration."""

DOMAIN = "learning_thermostat"
